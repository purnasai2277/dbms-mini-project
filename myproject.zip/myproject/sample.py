import sqlite3
import random
phno = "6302776109"
from flask import render_template
#cust_id = random.randint(10000,999999)
con = sqlite3.connect("register.db")
cursor_obj = con.cursor()
cursor_obj.execute("SELECT phno, cust_id FROM customer")
data = cursor_obj.fetchall()
lst_phno = []
lst_custid = []
for i in data:
    for r in range(1):
        lst_phno.append(str(i[0]))
        lst_custid.append(str(i[1]))
    
dict1 = dict()
for i in range(len(lst_custid)):
    dict1[lst_phno[i]] = str(lst_custid[i])

if "37075" == dict1[phno]:
    print(True)
else:
    print(False)