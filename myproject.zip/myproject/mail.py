import smtplib

def email(recv,cust_id):
    sender = 'purnasaikumarreddy@outlook.com'
    receivers = recv
    message = """
    Your customer ID is: """+str(cust_id)+"""
    """
    smtp = smtplib.SMTP("smtp.office365.com",587)
    smtp.starttls()
    smtp.login('purnasaikumarreddy@outlook.com', 'Sai@/0806')
    smtp.sendmail(sender, receivers, message)